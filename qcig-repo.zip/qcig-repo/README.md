# Qiskit Fall Fest — Wits University 2026

Welcome to the official repository for the **Qiskit Fall Fest** hosted by [team/club name] at the **University of the Witwatersrand (Wits)**! 🎉⚛️

Qiskit Fall Fest is a global series of quantum computing events organized by student communities, supported by IBM Quantum. This repo is where our team plans, builds, and shares everything related to hosting our event.

## 📅 Event Details

- **Event Name:** Qiskit Fall Fest — Wits University
- **Date(s):** TBD
- **Location:** TBD
- **Format:** In-person / Hybrid / Online *(update as needed)*

## 👥 Organizing Team

| Name | Role | GitHub |
|------|------|--------|
| Shawal | Team Lead | @ |
| [Your name] | [Your role] | @ |

*(Add each team member as they join the repo)*

## 📂 Repository Structure

```
├── slides/                        # Presentation decks and talk materials
├── workshops/                     # Hands-on workshop guides
├── notebooks/                     # Qiskit / quantum computing notebooks, one subfolder per session
│   ├── odepde-heat-equation/      #   ODE/PDE → quantum concepts session
│   │   ├── *.ipynb
│   │   └── environment.yml        #   conda env for THIS notebook only
│   ├── qiskit-ml/
│   │   └── environment.yml
│   ├── entanglement-tutorial/
│   │   └── environment.yml
│   └── max-clique/
│       └── environment.yml
├── registration/                  # Sign-up forms, attendee lists, logistics docs
├── marketing/                     # Posters, social media assets, flyers
└── README.md                      # You are here
```

Each session/workshop gets its **own subfolder** under `notebooks/`, with its notebook and its own `environment.yml` living together. This avoids filename clashes (several sessions end up needing a file literally called `environment.yml`) and means contributors only install what that specific session needs.

To use a session's environment:
```bash
conda env create -f notebooks/<session-name>/environment.yml
conda activate <env-name-from-the-yml>
```

## 🚀 Getting Started

1. Clone the repo:
   ```bash
   git clone https://github.com/[org-or-username]/[repo-name].git
   ```
2. Pull the latest changes before you start working:
   ```bash
   git pull
   ```
3. Add your files to the relevant folder, then commit and push:
   ```bash
   git add .
   git commit -m "Add [describe what you added]"
   git push
   ```

## 🤝 Contributing

This repo is for our organizing team. If you're a team member:
- Create a new branch for major changes (optional but recommended)
- Keep files organized in the correct folder
- Use clear commit messages so everyone knows what changed

## 📬 Contact

Questions about the event? Reach out to Shawal or the organizing team at [contact email].

## 📦 External Dependencies

Some sessions build on external open-source quantum libraries rather than vendoring their code into this repo. Install them via pip/conda as listed in that session's `environment.yml`, for example:

- **[vqls-prototype](https://github.com/QuantumApplicationLab/vqls-prototype)** — Variational Quantum Linear Solver prototype for Qiskit (Apache 2.0). Install with:
  ```bash
  pip install vqls-prototype
  ```

## 🔗 Useful Links

- [Qiskit Fall Fest official page](https://qiskit.org/events/fall-fest)
- [Qiskit documentation](https://docs.quantum.ibm.com/)
- [IBM Quantum Learning](https://learning.quantum.ibm.com/)
- [vqls-prototype (Quantum Application Lab)](https://github.com/QuantumApplicationLab/vqls-prototype)

---
*This repository is part of the global Qiskit Fall Fest 2026 series.*
